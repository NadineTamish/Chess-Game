
package ChessCore;


public interface GameObserver {
    
    public void updateSate(GameStatus status);
    
}
