

package ChessCore;

public enum Player {
    WHITE,
    BLACK;

    private Player() {
    }
}
