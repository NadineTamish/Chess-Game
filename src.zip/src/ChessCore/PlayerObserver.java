
package ChessCore;


public interface PlayerObserver {
     public Player updateSate(Player player);
    
}
