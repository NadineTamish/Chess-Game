

package ChessCore;

public enum PawnPromotion {
    None,
    Knight,
    Bishop,
    Rook,
    Queen;

    private PawnPromotion() {
    }
}
