

package ChessCore;

import ChessCore.Pieces.Piece;

public interface BoardInitializer {
    Piece[][] initialize();
}
